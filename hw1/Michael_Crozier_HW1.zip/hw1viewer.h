#ifndef EX01V_H
#define EX01V_H

#include <QWidget>

class hw1viewer : public QWidget
{
Q_OBJECT
public:
    hw1viewer();
};

#endif
