#ifndef NOISE_H
#define NOISE_H

void CreateNoise3D(int unit);

#endif
